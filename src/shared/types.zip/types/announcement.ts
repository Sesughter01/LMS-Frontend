export interface Announcement {
  id?: number;
  courseId?: number;
  title: string;
  announcement: string;
  createdAt: string;
}
