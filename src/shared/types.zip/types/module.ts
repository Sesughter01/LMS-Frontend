export interface Module {
  id: number;
  moduleTitle: string;
  moduleDescription: string;
  moduleSequencePosition: number;
  courseId: number;
}
