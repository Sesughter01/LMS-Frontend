
export interface QuestionAnswer{
    assessmentId: number,
    questionId: number,
    userSelectedOptionId: number,
    rightAnswerOptionId?: number
}