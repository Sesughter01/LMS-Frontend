export interface UserPayment {
  id: string;
  courseTitle: string;
  amount: number;
  paymentType: string;
  createdAt: string;
  status: string;
  courseSlug: string;
}
