export interface Organization {
  id?: number;
  organizationName: string;
  email: string;
  phoneNumber: string;
  colorScheme: string;
  logo?: string;
  subDomain: string;
  is_active?: boolean;
  createdAt?: any;
}
