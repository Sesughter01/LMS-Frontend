export interface Notification{
    title: string, 
    content: string, 

    isRead: boolean
}