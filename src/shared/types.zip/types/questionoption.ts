export interface QuestionOption {
    id: number,
    optionContent: string
    
}